This is some kind of hello-world test. There is a simple object,
a server and a client which calls the methods of the object.
Nothing fancy, just to check if PYRO works.

Also this is a nice starting point for your own Pyro projects.

HOW TO START THIS:

1) start a Pyro Name Server using the 'ns' command.
2) in a different console window, start the server using 'python server.py'.
3) in a third console window, run the client using 'python client.py'.


Have a look at the "example" chapter in the manual to see other
very simple Pyro examples.


NOTE : the client_thread.py script shows what happens when you share
a Pyro proxy among different threads.
