Testing the passing of code from client to server,
to another server, and finally back to the client.
A nameserver is required.
