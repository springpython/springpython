Testing the passing of code from client to server,
as well as server back to client.
No nameserver is required.
