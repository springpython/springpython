This is a Pyro Quickstart example that works without the Name Server.
It is adapted from the "quickstart" example (that uses the NS).
It used the "Pyro.ext.remote_nons" module.

For more information, see the source code and the "quickstart" example.
(but don't pay attention to all Name Server references).

