This test transfers huge data structures to see how Pyro handles those.
Also it uses the Delegate Pattern on the server side instead of
subclassing the Pyro.core.ObjBase.
