
class apples:
	def __init__(self):
		pass
	def getName(self):
		return "apples"
	def getDescription(self):
		return "Juicy green apples"
