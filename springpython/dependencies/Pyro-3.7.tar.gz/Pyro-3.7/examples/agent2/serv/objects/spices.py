
class spices:
	def __init__(self):
		pass
	def getName(self):
		return "spices"
	def getDescription(self):
		return "Various spicy spices"
