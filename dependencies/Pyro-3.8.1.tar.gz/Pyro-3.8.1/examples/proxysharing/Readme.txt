This example shows how Pyro deals with sharing proxies in different threads.
Due to internal locking you can freely share proxies.

