
class tomatoes:
	def __init__(self):
		pass
	def getName(self):
		return "tomatoes"
	def getDescription(self):
		return "four very big and very red tomatoes"
