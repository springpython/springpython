
class cd:
	def __init__(self):
		pass
	def getName(self):
		return "CD"
	def getDescription(self):
		return "The new album of the Red Hot Chili Peppers"
