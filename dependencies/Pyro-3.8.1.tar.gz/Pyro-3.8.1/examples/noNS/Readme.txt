This example shows the PYROLOC:// URI. You don't need a Name Server
if you use this. But this is not recommended because you miss
all the features of the Name Server.

However, just take a look at how simple the client is now!!

Also the client2.py uses the URI string directly if you could
somehow obtain it (the server prints it out, so copy-paste it).
It only contains two lines of Pyro code!


Please also read the documentation on the PYROLOC:// and PYRONAME:// URIs.

