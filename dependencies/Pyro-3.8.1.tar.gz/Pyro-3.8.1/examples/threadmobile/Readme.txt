This is a fairly technical test of using multiple threads
with the mobile code feature. It sort-of tests the thread-safety
of Pyro's mobile code import logic.

Make sure you activate PYRO_MOBILE_CODE for both the server
(in the server/ directory) and the client.

No nameserver is required.
