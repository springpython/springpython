char* pysqlite_strsep(char** stringp, const char* delim);
