* To install, just type (python-2.3 or later needed):

    python setup.py install

* To learn how to use it, look at the examples under cherrypy/tutorial/ or go to http://www.cherrypy.org for more info.

* To run the regression tests, just go to the cherrypy/test/ directory and type:

    python test.py

  Or to run individual tests type:

    python test.py --test_foo --test_bar
