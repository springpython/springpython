def test_eggs():
    assert True

